﻿namespace OOOControlSystem.Dtos
{
    public class DefectAssignDto
    {
        public int? AssignedToId { get; set; }
    }
}
