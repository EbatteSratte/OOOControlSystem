﻿namespace OOOControlSystem.Models.Enums
{
    public enum DefectPriority
    {
        Low,
        Medium,
        High,
        Critical
    }
}
