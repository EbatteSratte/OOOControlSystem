﻿namespace OOOControlSystem.Models.Enums
{
    public enum DefectStatus
    {
        New,
        InProgress,
        OnReview,
        Closed,
        Rejected
    }
}
