﻿namespace OOOControlSystem.Models.Enums
{
    public enum ProjectStatus
    {
        Active,
        Completed,
        OnHold
    }
}
