﻿namespace OOOControlSystem.Models.Enums
{
    public enum UserRole
    {
        Engineer,
        Manager,
        Customer
    }
}
